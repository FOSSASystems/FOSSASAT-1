var searchData=
[
  ['bandwidth',['BANDWIDTH',['../configuration_8cpp.html#a8a1bb433d870a97dd5584108636cdbc3',1,'BANDWIDTH():&#160;configuration.cpp'],['../configuration_8h.html#a8a1bb433d870a97dd5584108636cdbc3',1,'BANDWIDTH():&#160;configuration.cpp']]]
];
