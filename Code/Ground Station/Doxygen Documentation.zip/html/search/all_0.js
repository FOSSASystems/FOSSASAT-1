var searchData=
[
  ['automatic_5ftuning',['AUTOMATIC_TUNING',['../configuration_8cpp.html#ab1e5677d6b70e3965bdb8b1303d722f8',1,'AUTOMATIC_TUNING():&#160;configuration.cpp'],['../configuration_8h.html#ab1e5677d6b70e3965bdb8b1303d722f8',1,'AUTOMATIC_TUNING():&#160;configuration.cpp']]]
];
