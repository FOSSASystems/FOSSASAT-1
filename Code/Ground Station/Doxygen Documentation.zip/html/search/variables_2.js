var searchData=
[
  ['carrier_5ffrequency',['CARRIER_FREQUENCY',['../configuration_8cpp.html#a6f812a7f3ce771172c19e67b93772474',1,'CARRIER_FREQUENCY():&#160;configuration.cpp'],['../configuration_8h.html#a6f812a7f3ce771172c19e67b93772474',1,'CARRIER_FREQUENCY():&#160;configuration.cpp']]],
  ['coding_5frate',['CODING_RATE',['../configuration_8cpp.html#a058c5ebaef09467069080c27d0d07ff4',1,'CODING_RATE():&#160;configuration.cpp'],['../configuration_8h.html#a058c5ebaef09467069080c27d0d07ff4',1,'CODING_RATE():&#160;configuration.cpp']]],
  ['connected_5fbandwidth',['CONNECTED_BANDWIDTH',['../configuration_8cpp.html#a8b4922dd8446574ca5548ec99a1f23e1',1,'configuration.cpp']]]
];
