var searchData=
[
  ['transmission_5fsignature',['TRANSMISSION_SIGNATURE',['../configuration_8cpp.html#a82c428085c407e360d82a73ad8847b63',1,'TRANSMISSION_SIGNATURE():&#160;configuration.cpp'],['../configuration_8h.html#a82c428085c407e360d82a73ad8847b63',1,'TRANSMISSION_SIGNATURE():&#160;configuration.cpp']]]
];
