var indexSectionsWithContent =
{
  0: "abcdghlost",
  1: "cdgs",
  2: "cdls",
  3: "abcdhlost",
  4: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables",
  4: "Pages"
};

